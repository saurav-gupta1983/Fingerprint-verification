               
                TouchChip drivers for Windows version 2.9

	      Copyright (c) 2001-2008 UPEK
                    All Rights Reserved.
-------------------------------------------------------------------------

This ReadMe file contains information regarding the drivers for
UPEK's TouchChip and TouchStrip authentication hardware.


-------------------------------
SUPPORTED PRODUCTS
-------------------------------

This driver supports following products: 
- TouchStrip Chipset with USB interface based on chips TCD41,TCD42 or TCD50
- TouchStrip Sensor with USB interface based on chips TCS4A, TCS4B, TCS4C or TCS4E
- Products with in-built TouchStrip Chipset or TouchStrip Sensor (e.g. notebooks)
- TouchStrip USB fingerprint readers EIKON and TCRZ3
- TouchChip Trusted Fingerprint Module TCEBB1C with USB interface (TFM)
- TouchChip USB fingerprint readers TCRU1C, TCRU2C, TCRB1C, TCRU1A

Supported Operating Systems are: 
- Windows 2000/XP/Server2003/Vista on x86 platform
- XP/Server2003/Vista on x64 platform

The drivers are WHQL certified (digitally signed by Microsoft)

Note: Smartcard-enabled TouchChip readers (TCRP1C, TCRA1C, TCRS1C) are 
not supported by this driver. Dedicated driver version is available for these 
USB readers.


-------------------------------
PROTECTOR SUITE USERS
-------------------------------

Protector Suite QL users: Drivers are installed automatically as a part of 
the Protector Suite installation. It is not necessary to install the drivers separately.


-------------------------------
FILES
-------------------------------

Windows Vista driver on x86 platform:		tcusb.inf 	in x86.vista directory
Windows Vista driver on x64 platform:		tcusb.inf 	in x64.vista directory
Windows XP driver on x86 platform:		tcusb.inf 	in x86.xp directory
Windows XP driver on x64 platform:		tcusb.inf 	in x64.xp directory
Windows 2003 driver on x86 platform:		tcusb.inf 	in x86.w2k3 directory
Windows 2003 driver on x64 platform:		tcusb.inf 	in x64.w2k3 directory
Windows 2000 driver: 				tcusb2k.inf 	in x86.w2k directory


-------------------------------
INSTALLATION
-------------------------------

Devices with built-in fingerprint sensor (e.g. notebooks)
==============================

Follow these steps to install TouchChip driver if you are using a device with 
built-in fingerprint sensor (such as a notebook computer):

1) Open the Device Manager window. 
   (Right-click MyComputer icon, or use shortcut Windows Key + Pause,
   On Windows 2000/XP/Server2003: select "Hardware" tab and click the "Device Manager" button).
   On Vista: Device Manager in left column and proceed elevation.

2) On Windows 2000/XP/Vista - with TouchStrip, EIKON and TCRZ3 and TCEBB1C devices: 
   look for "Biometric" branch. If "TouchChip Fingerprint Coprocessor" 
   is listed with a yellow exclamation mark, right click the item, choose "Properties" and select 
   "Reinstall driver ...". This will invoke the Device Driver/Hardware Update Wizard.

   On Windows 2000/XP/Vista - with TouchChip area sensor devices:
   look for "Biometric" branch. If "TouchChip Fingerprint Reader" 
   is listed with a yellow exclamation mark, right click the item, choose "Properties" and select 
   "Reinstall driver ...". This will invoke the Device Driver/Hardware Update Wizard.

   On Windows Server2003:
   look for "Personal Identification devices" branch. If "TouchChip Fingerprint Reader" or 
   "TouchChip Fingerprint Coprocessor" are listed with a yellow exclamation mark, 
    right-click the item, choose "Properties" and select "Reinstall driver ...". 
    This will invoke the Device Driver/Hardware Update Wizard.


3) If you cannot find your device listed:
   On Windows 2000/XP/Server2003/Vista: perform "Scan for hardware changes".

4) Device Driver/Hardware Update Wizard will start and you will be prompted for drivers. 
   Insert the installation CD/driver CD and continue the wizard by choosing  
   "Specify the location of driver". Select the directory that includes TouchChip drivers 
   (if you have obtained original CD from TouchChip, drivers are stored in \Drivers directory) and 
   complete the wizard.


TCRU, TCRB, TCRZ, TCEBB1C and other devices connected to USB port
==============================

Follow these steps to install the TouchChip driver for your USB device:

1) Plug in your fingerprint device.

2) "Found New Hardware" or similar dialog is displayed.

    If no such dialog is displayed, proceed as follows:
    a. Open the Device Manager window: �
       (Right-click My Computer icon, or use the Windows Key + Pause shortcut,
       on Windows2000/XP/Server2003: select "Hardware" tab and click the "Device Manager" button).
       on Vista: Select Device manager in the left column and proceed elevation.
    b. If "TouchChip Fingerprint Reader" or "TouchChip Fingerprint Coprocessor" 
       are listed with a yellow exclamation mark in "Biometric" branch (Windows 2000/XP/Vista)
       or under "Personal Identification devices" branch (Windows Server2003), right click such item, 
       choose "Properties" and select "Reinstall driver ...". 
       This will invoke the Device Driver / Hardware Update Wizard.
